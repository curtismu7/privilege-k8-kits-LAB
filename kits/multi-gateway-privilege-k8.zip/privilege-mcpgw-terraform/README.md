# PingOne Privilege AI Gateway — Terraform (Kubernetes)

Shareable Terraform for the platform side of the **PingOne Privilege AI Gateway**
(agentless MCP gateway) deployment described in the companion guide,
*"PingOne Privilege AI Gateway — Kubernetes Deployment Guide"*.

This stack provisions:

| Piece | What it does |
|---|---|
| Namespaces | One Kubernetes namespace per gateway node |
| Image pull secret | For private registries (optional) |
| Redis (Bitnami chart) | Shared store for dynamic client registrations — survives gateway restarts and failover |
| `privilege-redis-url` secrets | The `MCPGW_REDIS_URL` value, in every node's namespace |
| Gateway Helm releases | One `agentless-mcpgw` release per node, wired to shared Redis, with the integrated load balancer on the primary node |

It does **not** provision: the OIDC application (create it in PingFederate or
PingOne — section 4 of the guide), enrollment tokens (console-generated,
single-use, ~2h), or the ingress controller / cert-manager / DNS (cluster
prerequisites — section 3 of the guide).

## What is in this package

| Path | What it is |
|---|---|
| `docs/PingOne-Privilege-AI-Gateway-K8s-Deployment-Guide.pdf` | The deployment guide (18 pages). Start here. |
| `docs/CHECKLIST.md` | One-page go-live checklist drawn from the guide. |
| `main.tf`, `variables.tf`, `outputs.tf`, `versions.tf` | The Terraform. |
| `terraform.tfvars.example` | Copy to `terraform.tfvars` and edit. |
| `scripts/preflight.sh` | Read-only checks of your tools and cluster before you deploy. |
| `scripts/validate.sh` | `terraform init`, `fmt` and `validate`, with no cluster needed. |
| `scripts/smoke.sh` | Post-deploy check of a gateway node: rolled out, enrolled, Redis connected. |

## Prerequisites

- Terraform >= 1.6
- A Kubernetes cluster. On **Google GKE** the stack installs ingress-nginx via
  Helm; its Service becomes a Google Network Load Balancer — point DNS for the
  gateway hostname at the `ingress_controller_external_ip` output. cert-manager
  and a ClusterIssuer (e.g. `letsencrypt-prod` via HTTP-01 through the same
  ingress) must exist; other platforms need an nginx ingress controller with the
  same long-timeout configuration (the chart's ingress annotations assume it).
- The Ping-supplied `agentless-mcpgw` Helm chart, reachable from where you run
  Terraform (OCI registry, internal Helm repo, or a local path). The chart is
  self-contained: no OpenSearch, no demo MCP servers, no bundled sidecars.
  Backends are whatever you register as applications in the Privilege console.
- An OIDC identity provider. Works with PingFederate, PingOne, or any provider
  implementing the authorization-code flow with `client_secret_basic` (and the
  token-exchange grant if you use delegation). The application needs redirect
  `https://<host>/callback` and scopes `openid profile email`.

### Why nginx (and not the GKE Gateway)

The gateway chart's ingresses use nginx annotations that a GKE-native Gateway
cannot honor, and Ping's upstream chart lists the nginx ingress controller as a
prerequisite: 3600 s proxy read/send timeouts (MCP SSE streams are long-lived),
proxy-buffering off, HTTPS backends, and SSL redirect. ingress-nginx on GKE
fronts a Google Network Load Balancer, so you keep the cloud LB while the
annotation semantics stay intact.

## Quick start

```bash
scripts/preflight.sh --context my-cluster   # tools and cluster checks (read-only)
cp terraform.tfvars.example terraform.tfvars
# edit terraform.tfvars: cluster, chart source, nodes, OIDC values

terraform init
terraform plan
terraform apply

scripts/smoke.sh <namespace> <release> --context my-cluster   # per node, see Helper scripts
```

The step-by-step reasoning behind each value is in `docs/PingOne-Privilege-AI-Gateway-K8s-Deployment-Guide.pdf`;
`docs/CHECKLIST.md` is the short version.

Enrollment tokens are pasted into `terraform.tfvars` (or better, supplied as
environment variables — see below). They are single use and expire in about two
hours; strip all leading/trailing whitespace before saving. If a token is spent
or expired, generate a new one in the Privilege console, move the node's old
enrollment files aside (delete the node's `*-ssl` PVC), and `terraform apply`
with the new token.

## Adding a second node

1. In the Privilege console, **Gateways → Add New → AI GW** with the **same
   Cluster ID** as the first node, and the new node's in-cluster Service name as
   Host IP.
2. Add a second entry to `gateway_nodes` in `terraform.tfvars`
   (`ingress_enabled = false`, same `hostname`).
3. `terraform apply`.

Every application registered on the mesh cluster is served by every node; no
registration is duplicated.

## Helper scripts

```bash
scripts/preflight.sh --context my-cluster --chart /path/to/agentless-mcpgw   # before you deploy (read-only)
scripts/validate.sh                                                           # static checks, no cluster
scripts/smoke.sh <namespace> <release> --context my-cluster                   # after terraform apply, once per node
```

`<namespace>` and `<release>` come from `terraform output gateway_namespaces` and
`terraform output gateway_release_names`. `scripts/selftest.sh` exercises the scripts against stub tools and needs
no cluster.

## Sensitive values

`proxy_token`, `oidc_client_secret` and registry credentials are marked
sensitive and stored in state. Prefer environment variables:

```bash
export TF_VAR_oidc_client_secret='...'
export TF_VAR_image_pull_password='...'
```

and keep only non-secret values in `terraform.tfvars`. For shared/CI use, add a
remote backend with state encryption.

## Operations (from the guide — read before running)

- **Never restart a gateway while Redis is down** — the gateway exits after six
  failed attempts and crash-loops until Redis returns.
- **OIDC changes need a pod restart**: `kubectl -n <ns> rollout restart deploy/<release>`.
- **503 with `node=<NOSRV>` right after a rollout is normal**: the LB holds a
  node out for ~10 minutes of health-check rise. Do not restart gateways in
  response.
- An app's **entry path is sticky**; register backends with `/mcp`, never `/sse`.
- Editing an app's Mesh Cluster in the console **moves** it, it does not copy it.
- The load balancer **pins** each client + application to one node. Tokens are
  not shared between nodes; failover costs affected clients an automatic
  re-authentication (~20 s), while registrations survive via Redis.

## Layout

```
main.tf                     namespaces, secrets, Redis, gateway Helm releases
variables.tf                all inputs (documented)
outputs.tf                  endpoints and secret names
versions.tf                 Terraform and provider versions
terraform.tfvars.example    copy to terraform.tfvars and edit
docs/                       deployment guide (PDF), checklist, and the guide source
scripts/                    preflight, validate, smoke, selftest
```

## Notice

This repository and the deployment guide are shared with you as a reference deployment and are provided as-is.
Values shown are examples: substitute your own hostnames, namespaces and identifiers. The guide is marked
"Ping Identity Proprietary and Confidential"; please do not redistribute it.
