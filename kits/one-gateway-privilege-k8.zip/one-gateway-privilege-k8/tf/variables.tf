variable "kubeconfig_path" {
  description = "Path to the kubeconfig file."
  type        = string
  default     = "~/.kube/config"
}

variable "kube_context" {
  description = "kubectl context to deploy into."
  type        = string
}

variable "gateway_nodes" {
  description = <<-DESC
    Map of gateway nodes to deploy. Each entry becomes one Helm release in its
    own namespace. Keys are release names (e.g. "agent-privilege",
    "agent-privilege2"). The first node listed hosts Redis by default.

    Each value:
      namespace         - k8s namespace for this node
      hostname          - public hostname the gateway answers on
      oidc_server_url   - public URL the gateway advertises in OAuth metadata
                          (must match the ingress TLS certificate)
      ingress_enabled   - true only for the primary node; additional nodes are
                          reached through the load balancer
      load_balancer_enabled - integrated load balancer (mcpgw-lb, part of the
                          chart) is OPTIONAL. True only on the primary node;
                          secondary nodes and single-node deployments leave it
                          false. Set false on every node if you bring your own
                          external load balancer (Kong, F5, standalone HAProxy —
                          see section 7 of the deployment guide).
      proxy_token       - single-use enrollment token from the Privilege console
                          (strip ALL leading/trailing whitespace)
      extra_values      - extra raw YAML (string) merged into the release,
                          e.g. sidecar values
  DESC
  type = map(object({
    namespace             = string
    hostname              = string
    oidc_server_url       = string
    ingress_enabled       = bool
    load_balancer_enabled = bool
    proxy_token           = string
    extra_values          = optional(list(string), [])
  }))
}

variable "oidc_client_id" {
  description = "PingOne OIDC application client ID (Client Secret Basic, Authorization Code + Token Exchange)."
  type        = string
  sensitive   = true
}

variable "oidc_client_secret" {
  description = "PingOne OIDC application client secret."
  type        = string
  sensitive   = true
}

variable "oidc_auth_url" {
  description = "Authorization endpoint. PingFederate: https://pf.example.com/as/authorization.oauth2 — PingOne: https://auth.pingone.com/<environmentId>/as/authorize."
  type        = string
}

variable "oidc_token_url" {
  description = "Token endpoint (must also allow the token-exchange grant if you use delegation). PingFederate: https://pf.example.com/as/token.oauth2."
  type        = string
}

variable "oidc_user_url" {
  description = "UserInfo endpoint. PingFederate: https://pf.example.com/idp/userinfo.openid."
  type        = string
}

variable "chart_repository" {
  description = <<-DESC
    Location of the Ping-supplied agent-privilege chart. Examples:
      - "oci://registry.example.com/ping"        (OCI; set chart_name accordingly)
      - "https://charts.example.internal/ping"   (Helm repo)
      - "file:///path/to/path/to/agent-privilege" (local path)
  DESC
  type        = string
}

variable "chart_name" {
  description = "Chart name within the repository (agent-privilege)."
  type        = string
  default     = "agent-privilege"
}

variable "chart_version" {
  description = "Chart version. Pin explicitly in shared environments."
  type        = string
  default     = null
}

variable "gateway_service_port" {
  description = "Port the gateway Service listens on (peers dial this)."
  type        = number
  default     = 8623
}

variable "ingress_class_name" {
  description = "Ingress class the gateway chart's ingresses use (must match the installed controller)."
  type        = string
  default     = "nginx"
}

variable "cluster_issuer" {
  description = "cert-manager ClusterIssuer for the gateway TLS certificate (e.g. letsencrypt-prod; the issuer must exist in the cluster)."
  type        = string
  default     = "letsencrypt-prod"
}

variable "lb_fail_timeout_seconds" {
  description = "How long the load balancer holds a failed node out of rotation."
  type        = number
  default     = 600
}

variable "redis_namespace_node" {
  description = "Key of the gateway node whose namespace hosts Redis."
  type        = string
}

variable "redis_service_name" {
  description = "Redis Service name created by the Redis chart."
  type        = string
  default     = "privilege-redis-master"
}

variable "redis_port" {
  description = "Redis port."
  type        = number
  default     = 6379
}

variable "redis_chart_version" {
  description = "Bitnami Redis chart version. Pin explicitly."
  type        = string
  default     = "19.6.2"
}

variable "redis_storage_size" {
  description = "Redis persistent volume size (append-only persistence)."
  type        = string
  default     = "1Gi"
}

variable "redis_memory_limit" {
  description = "Redis memory limit; registrations are small."
  type        = string
  default     = "256Mi"
}

variable "image_pull_registry" {
  description = "Container registry requiring authentication (e.g. ghcr.io). Null = no pull secret."
  type        = string
  default     = null
}

variable "image_pull_username" {
  description = "Registry username."
  type        = string
  default     = null
  sensitive   = true
}

variable "image_pull_password" {
  description = "Registry password/token."
  type        = string
  default     = null
  sensitive   = true
}
