###############################################################################
# PingOne Privilege AI Gateway — shareable Kubernetes deployment
#
# Provisions the platform for the agent-privilege Helm chart:
#   - namespaces (one per gateway node)
#   - image pull secret
#   - Redis (shared client-registration store) with password + URL secrets
#   - placeholder wiring for the gateway release itself
#
# The gateway enrollment token and OIDC credentials are supplied as variables
# and are never written to state in plaintext; see variables.tf.
#
# Companion guide: "PingOne Privilege AI Gateway — Kubernetes Deployment Guide".
###############################################################################

provider "kubernetes" {
  config_path    = var.kubeconfig_path
  config_context = var.kube_context
}

provider "helm" {
  kubernetes {
    config_path    = var.kubeconfig_path
    config_context = var.kube_context
  }
}

locals {
  node_names       = keys(var.gateway_nodes)
  image_pull_nodes = var.image_pull_registry == null ? toset([]) : toset(keys(var.gateway_nodes))
}

###############################################################################
# Namespaces — one per gateway node
###############################################################################

resource "kubernetes_namespace" "gateway" {
  for_each = var.gateway_nodes

  metadata {
    name = each.value.namespace
  }
}

###############################################################################
# Image pull secret (optional; required for private registries)
###############################################################################

resource "kubernetes_secret" "image_pull" {
  for_each = local.image_pull_nodes

  metadata {
    name      = "ghcr-pull-secret"
    namespace = kubernetes_namespace.gateway[each.key].metadata[0].name
  }

  type = "kubernetes.io/dockerconfigjson"

  data = {
    ".dockerconfigjson" = jsonencode({
      auths = {
        (var.image_pull_registry) = {
          username = var.image_pull_username
          password = var.image_pull_password
          auth     = base64encode("${var.image_pull_username}:${var.image_pull_password}")
        }
      }
    })
  }
}

###############################################################################
# Shared Redis — durable dynamic-client-registration store
#
# Deployed once, in the first node's namespace. Every gateway reads the URL
# from a secret named `privilege-redis-url` (key `url`). The gateway requires
# the env var MCPGW_REDIS_URL; a bare REDIS_URL is ignored.
#
# A gateway that cannot reach Redis at startup exits after six attempts, so
# Redis is created before any gateway release.
###############################################################################

resource "random_password" "redis" {
  length  = 32
  special = false
}

resource "kubernetes_secret" "redis_password" {
  metadata {
    name      = "privilege-redis"
    namespace = kubernetes_namespace.gateway[var.redis_namespace_node].metadata[0].name
  }

  data = {
    password = random_password.redis.result
  }
}

resource "kubernetes_secret" "redis_url" {
  for_each = var.gateway_nodes

  metadata {
    name      = "privilege-redis-url"
    namespace = kubernetes_namespace.gateway[each.key].metadata[0].name
  }

  data = {
    url = "redis://:${random_password.redis.result}@${var.redis_service_name}.${kubernetes_namespace.gateway[var.redis_namespace_node].metadata[0].name}.svc.cluster.local:${var.redis_port}/0"
  }
}

resource "helm_release" "redis" {
  name       = "privilege-redis"
  repository = "https://charts.bitnami.com/bitnami"
  chart      = "redis"
  namespace  = kubernetes_namespace.gateway[var.redis_namespace_node].metadata[0].name
  version    = var.redis_chart_version

  set {
    name  = "architecture"
    value = "standalone"
  }

  set {
    name  = "auth.existingSecret"
    value = kubernetes_secret.redis_password.metadata[0].name
  }

  set {
    name  = "auth.existingSecretPasswordKey"
    value = "password"
  }

  set {
    name  = "master.persistence.size"
    value = var.redis_storage_size
  }

  set {
    name  = "master.resources.limits.memory"
    value = var.redis_memory_limit
  }
}

###############################################################################
# Ingress controller — nginx.
#
# The gateway chart's ingress uses nginx annotations (long read/send timeouts
# for streaming MCP/SSE connections, proxy-buffering off, HTTPS backends), so
# an nginx ingress controller is required regardless of platform. On Google
# GKE this creates a Google Network Load Balancer; get its IP with:
#   kubectl get svc -n ingress-nginx ingress-nginx-controller
# and point DNS at it. Set enable_ingress_nginx=false if you already run one.
###############################################################################

variable "enable_ingress_nginx" {
  description = "Install the ingress-nginx controller (required by the gateway chart's ingress annotations)."
  type        = bool
  default     = true
}

variable "ingress_nginx_chart_version" {
  description = "ingress-nginx Helm chart version. Pin explicitly."
  type        = string
  default     = "4.11.3"
}

resource "helm_release" "ingress_nginx" {
  count = var.enable_ingress_nginx ? 1 : 0

  name       = "ingress-nginx"
  repository = "https://kubernetes.github.io/ingress-nginx"
  chart      = "ingress-nginx"
  namespace  = "ingress-nginx"
  version    = var.ingress_nginx_chart_version

  create_namespace = true

  set {
    name  = "controller.ingressClassResource.name"
    value = var.ingress_class_name
  }

  set {
    name  = "controller.config.proxy-read-timeout"
    value = "3600"
  }

  set {
    name  = "controller.config.proxy-send-timeout"
    value = "3600"
  }

  set {
    name  = "controller.config.proxy-buffering"
    value = "off"
  }

  # On GKE the controller's Service type LoadBalancer provisions a Google
  # Network Load Balancer automatically; capture its IP for DNS.
  set {
    name  = "controller.service.type"
    value = "LoadBalancer"
  }
}
#
# Requires the Ping-supplied agent-privilege chart. Point chart_repository at
# your internal chart museum / OCI registry / local path.
###############################################################################

resource "helm_release" "gateway" {
  for_each = var.gateway_nodes

  name       = each.key
  repository = var.chart_repository
  chart      = var.chart_name
  version    = var.chart_version
  namespace  = kubernetes_namespace.gateway[each.key].metadata[0].name

  values = concat(
    [yamlencode({
      hostname  = each.value.hostname
      namespace = each.value.namespace

      nameOverride = each.key

      ingress = {
        enabled          = each.value.ingress_enabled
        ingressClassName = var.ingress_class_name
        clusterIssuer    = var.cluster_issuer
      }

      oidc = {
        serverUrl = each.value.oidc_server_url
      }

      redis = {
        urlSecret = {
          name = kubernetes_secret.redis_url[each.key].metadata[0].name
          key  = "url"
        }
      }

      loadBalancer = {
        enabled     = each.value.load_balancer_enabled
        failTimeout = "${var.lb_fail_timeout_seconds}s"
        # X-Served-By label for this release's own gateway.
        ownName = "gateway-${index(local.node_names, each.key) + 1}"
        peers = [
          # One entry per peer node. The release that owns the load balancer
          # lists every OTHER node here; those nodes serve plain HTTP because
          # their OAuth URL does not match their (absent) certificate.
          for peer_key, peer in var.gateway_nodes : {
            name    = "gateway-${index(local.node_names, peer_key) + 1}"
            address = "${helm_release.gateway[peer_key].name}.${peer.namespace}.svc.cluster.local:${var.gateway_service_port}"
            scheme  = peer_key == each.key ? "http" : "http"
            parked  = false
          } if peer_key != each.key
        ]
      }
    })],
    each.value.extra_values
  )

  # Enrollment token + OIDC credentials come from the environment (or -var),
  # never committed. proxyToken is single-use and lives ~2 hours.
  set_sensitive {
    name  = "proxyToken"
    value = each.value.proxy_token
  }

  set_sensitive {
    name  = "oidc.clientId"
    value = var.oidc_client_id
  }

  set_sensitive {
    name  = "oidc.clientSecret"
    value = var.oidc_client_secret
  }

  set {
    name  = "oidc.authUrl"
    value = var.oidc_auth_url
  }

  set {
    name  = "oidc.tokenUrl"
    value = var.oidc_token_url
  }

  set {
    name  = "oidc.userUrl"
    value = var.oidc_user_url
  }

  # OIDC values are read from the secret at pod start; a change needs a restart.
  depends_on = [helm_release.redis, helm_release.ingress_nginx]
}
