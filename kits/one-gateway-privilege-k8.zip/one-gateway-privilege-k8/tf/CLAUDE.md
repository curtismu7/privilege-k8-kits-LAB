# privilege-mcpgw-terraform

Terraform for the PingOne Privilege AI Gateway platform on Kubernetes:
namespaces, image pull secret, shared Redis (client-registration store with
`MCPGW_REDIS_URL` wiring), and one `agent-privilege` Helm release per gateway
node with the integrated load balancer. Companion to the customer PDF
"PingOne Privilege AI Gateway — Kubernetes Deployment Guide".

## Run / test

```bash
terraform init -backend=false
terraform fmt -check -diff
terraform validate
```

`terraform.tfvars.example` shows the full shape; never commit a real
`terraform.tfvars` (gitignored). Enrollment tokens and OIDC secrets go in via
`TF_VAR_*` env vars or a local tfvars file.

## Rules that bite

- This repo deploys to **real clusters** — `apply` is owner-run only; agents
  stop at `plan`.
- The Ping `agent-privilege` chart is not public: `chart_repository` points at
  the user's own copy. Never vendor the chart or its values here.
- No real hostnames, tenant ids, client ids or environment names anywhere —
  only `.example`/`example.com` placeholders.
- Helm value quirks encoded in the config: `MCPGW_REDIS_URL` (not `REDIS_URL`),
  gateway 2+ must set `ingress.enabled=false`, OIDC changes need a pod restart.
