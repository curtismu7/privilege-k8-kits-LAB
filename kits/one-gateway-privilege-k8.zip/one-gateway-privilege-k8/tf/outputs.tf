output "gateway_namespaces" {
  description = "Namespace created per gateway node."
  value       = { for k, v in var.gateway_nodes : k => kubernetes_namespace.gateway[k].metadata[0].name }
}

output "redis_url_secret_names" {
  description = "Secret holding the shared Redis URL, per namespace (key: url)."
  value       = { for k, v in kubernetes_secret.redis_url : k => v.metadata[0].name }
}

output "gateway_release_names" {
  description = "Helm release names for each gateway node."
  value       = keys(helm_release.gateway)
}

output "ingress_controller_external_ip" {
  description = "External IP of the ingress-nginx controller (point DNS for the gateway hostname at this). Null when the controller is externally managed."
  value       = var.enable_ingress_nginx ? try(data.kubernetes_service.ingress_nginx[0].status[0].load_balancer[0].ingress[0].ip, null) : null
}

data "kubernetes_service" "ingress_nginx" {
  count = var.enable_ingress_nginx ? 1 : 0

  metadata {
    name      = "ingress-nginx-controller"
    namespace = "ingress-nginx"
  }
}

output "redis_endpoint" {
  description = "In-cluster Redis endpoint the gateways are wired to."
  value       = "${var.redis_service_name}.${kubernetes_namespace.gateway[var.redis_namespace_node].metadata[0].name}.svc.cluster.local:${var.redis_port}"
}
